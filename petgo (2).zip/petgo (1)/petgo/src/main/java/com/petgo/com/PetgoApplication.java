package com.petgo.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetgoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetgoApplication.class, args);
	}

}
